<?php
// 配置文件，定义插件目录路径和 URL
if ( ! defined( 'ZHUIGE_XCX_ADDONS_DIR' ) ) {
    define( 'ZHUIGE_XCX_ADDONS_DIR', plugin_dir_path( __FILE__ ) );
    define( 'ZHUIGE_XCX_ADDONS_URL', plugin_dir_url( __FILE__ ) );
}
