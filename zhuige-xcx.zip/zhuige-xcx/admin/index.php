<?php

// 包含身高预测代码
require_once plugin_dir_path(__FILE__) . 'addons/sgtool/sgtest/sgtest.php';

// 其他插件代码...

?>